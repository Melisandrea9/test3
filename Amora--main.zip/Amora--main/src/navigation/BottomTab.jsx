import { Ionicons, Feather } from "@expo/vector-icons";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import React from "react";
import { gradients } from "../constants/colors";

import { Home, Inbox, Profile } from "../screens";

const BottomTab = createBottomTabNavigator();

export function BottomTabNavigator() {
    const screenOptions = ({ route }) => ({
        tabBarIcon: ({ focused }) => {
            if (route.name === "Home") {
                return <Ionicons name="home-outline" size={24} color={focused ? gradients.primary[1] : "white"} />;
            }

            if (route.name === "Inbox") {
                return <Feather name="mail" size={24} color={focused ? gradients.primary[1] : "white"} />;
            }

            if (route.name === "Profile") {
                return <Feather name="user" size={24} color={focused ? gradients.primary[1] : "white"} />;
            }
        },
        tabBarShowLabel: false,
        headerLeftContainerStyle: {
            left: 20,
        },
        headerRightContainerStyle: {
            right: 20,
        },
        tabBarStyle: [
            {
                borderTopWidth: 0.2,
                borderTopColor: "gray",
            },
            null,
        ],
    });

    return (
        <BottomTab.Navigator initialRouteName="Home" screenOptions={screenOptions}>
            <BottomTab.Screen name="Home" component={Home} />
            <BottomTab.Screen name="Inbox" component={Inbox} />
            <BottomTab.Screen name="Profile" component={Profile} />
        </BottomTab.Navigator>
    );
}
