import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useAuth } from "../hooks";
import { Register, WebView, Login, SetProfile, UploadPhotos, UpdateProfile, Match, Message, Modal, CalculationDetails } from "../screens";
import { BottomTabNavigator } from "./BottomTab";

const Stack = createNativeStackNavigator();

export function StackNavigator() {
    const stackScreenOptions = {
        gestureEnabled: false,
    };

    const navScreenOptions = {
        headerShown: false,
    };

    const {user} = useAuth();

    return (
        <Stack.Navigator screenOptions={navScreenOptions}>
            {
                user
                    ? (
                        <Stack.Group>
                            <Stack.Screen options={stackScreenOptions} name="TabNav" component={BottomTabNavigator} />
                            <Stack.Screen options={stackScreenOptions} name="Match" component={Match} />
                            <Stack.Screen options={stackScreenOptions} name="Message" component={Message} /> 
                            <Stack.Screen options={stackScreenOptions} name="CalculationDetails" component={CalculationDetails} /> 
                            <Stack.Screen
                                options={{ ...stackScreenOptions, headerShown: true, headerTitle: "Edit Profile" }}
                                name="UpdateProfile"
                                component={UpdateProfile}
                            />
                        </Stack.Group>
                    )  
                    : (
                        <Stack.Group>
                            <Stack.Screen options={stackScreenOptions} name="Register" component={Register} />
                            <Stack.Screen options={stackScreenOptions} name="Login" component={Login} />
                            <Stack.Screen options={stackScreenOptions} name="WebView" component={WebView} />
                            <Stack.Screen options={stackScreenOptions} name="SetProfile" component={SetProfile} />
                            <Stack.Screen options={stackScreenOptions} name="UploadPhotos" component={UploadPhotos} />
                            <Stack.Screen options={{...stackScreenOptions, presentation: "modal"}} name="Modal" component={Modal} />
                        </Stack.Group>
                    )
            }
        </Stack.Navigator>
    );
}
