import { NavigationContainer, DarkTheme } from "@react-navigation/native";
import React from "react";

import { StackNavigator } from "./Stack";

export default function AppNavigator() {
    return (
        <NavigationContainer theme={DarkTheme}>
            <StackNavigator />
        </NavigationContainer>
    );
}
