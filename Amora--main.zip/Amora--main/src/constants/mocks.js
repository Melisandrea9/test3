import dayjs from "dayjs";

export const CARDS = [
    {
        id: "1",
        firstName: "Jack",
        lastName: "Phillips",
        age: 29,
        occupation: "Software Developer",
        photoURL: "https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?fit=crop&w=80&q=80",
    },
    {
        id: "2",
        firstName: "Devin",
        lastName: "Coldewey",
        age: 35,
        occupation: "Software Developer",
        photoURL: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?fit=crop&w=80&q=80",
    },
    {
        id: "3",
        firstName: "Bella",
        lastName: "Audrey",
        age: 22,
        occupation: "Software Developer",
        photoURL: "https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?fit=crop&w=80&q=80",
    },
];

export const USERS = [
    {
        id: 1,
        name: "Devin Coldewey",
        department: "Marketing Manager",
        stats: { posts: 323, followers: 53200, following: 749000 },
        social: { twitter: "CreativeTim", dribbble: "creativetim" },
        about:
      "Decisions: If you can’t decide, the answer is no. If two equally difficult paths, choose the one more painful in the short term (pain avoidance is creating an illusion of equality).",
        avatar: "https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?fit=crop&w=80&q=80",
    },
    {
        id: 2,
        name: "Bella Audrey",
        department: "Marketing Manager",
        stats: { posts: 323, followers: 53200, following: 749000 },
        social: { twitter: "CreativeTim", dribbble: "creativetim" },
        about:
      "Decisions: If you can’t decide, the answer is no. If two equally difficult paths, choose the one more painful in the short term (pain avoidance is creating an illusion of equality).",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?fit=crop&w=80&q=80",
    },
];

export const MESSAGES = [
    {
        _id: 1,
        text: "Bye, bye 👋🏻",
        createdAt: dayjs().subtract(1, "m").toDate(),
        user: {
            _id: "rVudpgbiqKWSab50cUdQFO9ZUJB2",
            name: USERS[0].name,
            avatar: USERS[0].avatar,
        },
    },
    {
        _id: 2,
        text: "Ok. Cool! See you 😁",
        createdAt: dayjs().subtract(2, "m").toDate(),
        user: {
            _id: USERS[1].id,
            name: USERS[1].name,
            avatar: USERS[1].avatar,
        },
    },
    {
        _id: 3,
        text: "Sure, just let me finish somerhing and I’ll call you.",
        createdAt: dayjs().subtract(3, "m").toDate(),
        user: {
            _id: "rVudpgbiqKWSab50cUdQFO9ZUJB2",
            name: USERS[0].name,
            avatar: USERS[0].avatar,
        },
    },
    {
        _id: 4,
        text: "Hey there! How are you today? Can we meet and talk about location? Thanks!",
        createdAt: dayjs().subtract(4, "m").toDate(),
        user: {
            _id: USERS[1].id,
            name: USERS[1].name,
            avatar: USERS[1].avatar,
        },
    },
];
