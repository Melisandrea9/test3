export const colors = {};

export const gradients = {
    default: ["#232526", "#414345"],
    primary: ["#f2d9f2", "#852e85"],
    secondary: ["#f4c4f3", "#fc67fa"],
    tetriary: ["#f857a6", "#ff5858"],
};

export const sizes = {};
