import React, { useState, useCallback } from "react";
import {View,Text,StyleSheet,Image,KeyboardAvoidingView,Keyboard} from "react-native";
import {
    heightPercentageToDP as hp,
    widthPercentageToDP as wp,
} from "react-native-responsive-screen";
import { showToast, validateRegistrationFields } from "../helpers";

import {Button, Input} from "../components";

import BouncyCheckbox from "react-native-bouncy-checkbox";
import { gradients } from "../constants/colors";

export default function Register({ navigation }) {
    const [registration, setRegistration] = useState({
        username: "",
        email: "",
        password: "" ,
        agreed: false, 
    });

    const handleChange = useCallback(
        (value) => {
            setRegistration((state) => ({...state, ...value}));
        },
        [setRegistration],
    );

    const signUp = () => {
        Keyboard.dismiss();
        const error = validateRegistrationFields(registration);
        if (error) {
            showToast(error);  
        } else {
            navigation.navigate("SetProfile", {registration});
        } 
    };

    return (
        <KeyboardAvoidingView
            keyboardVerticalOffset={-100}
            enabled
            behavior="position"
            style={styles.container}
        >
            {/* Logo */}
            <Image style={styles.image} resizeMode="contain" source={require("../../assets/icon.png")} />

            {/* Register inputs */}
            <View style={styles.inputsWrapper}>
                <Input
                    value={registration.username}
                    onChangeText={(value) => handleChange({username: value})}
                    placeholder="Enter your name"
                />
                <Input
                    value={registration.email}
                    autoCapitalize="none"
                    keyboardType="email-address"
                    onChangeText={(value) => handleChange({email: value})}
                    placeholder="Enter your email address"
                />
                <Input
                    secureTextEntry
                    value={registration.password}
                    onChangeText={(value) => handleChange({password: value})}
                    placeholder="Pick a strong password"
                />

                <BouncyCheckbox
                    style={styles.checkbox}
                    size={25}
                    fillColor={gradients.primary[1]}
                    unfillColor="#292C3A"
                    textComponent={
                        <Text style={styles.checkboxTxt}>
                            By clicking this button you are accepting our
                            <Text onPress={() => navigation.navigate("WebView", {title: "Privacy Policy", url: "https://www.privacypolicies.com/live/2b37fb29-674d-4785-aae6-badcd934c489"})} style={[styles.checkboxTxt, {textDecorationLine: "underline"}]}> Privacy policy</Text>
                        </Text>
                    }
                    onPress={(isChecked) => handleChange({agreed: isChecked})}
                />

                {/* Button */}
                <Button onPress={signUp} title="Sign Up Now" />

                {/* footer txt */}
                <Text onPress={() => navigation.navigate("Login")} style={styles.text}>
          Already have an account? Login
                </Text>
            </View>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#000",
    },
    inputsWrapper: {
        marginTop: "10%",
        padding: "4%",
    },
    checkbox: {
        marginVertical: hp("3%"),
    },
    checkboxTxt: {
        marginLeft: 10,
        width: "80%",
        fontWeight: "600",
        fontSize: hp("1.6%"),
        lineHeight: hp("2.2%"),
        color: gradients.primary[0],
    },
    text: {
        color: "#fbd3e9",
        shadowColor: "#bb377d",
        shadowOffset: { width: 4, height: 4 },
        shadowOpacity: 0.9,
        shadowRadius: 5,
        fontWeight: "bold",
        textAlign: "center",
        marginTop: hp("2%"),
        fontSize: hp("1.9%"),
    },
    image: {
        width: wp("100%"),
        height: hp("30%"),
        marginTop: hp("8%"),
    },
});
