import React from "react";
import { View, Text } from "react-native";
import { useLayoutEffect } from "react";
import { useNavigation, useRoute } from "@react-navigation/native";
import { Entypo } from "@expo/vector-icons";
import { WebView as RNWebView } from "react-native-webview";

export default function WebView() {
    const route = useRoute();
    const navigation = useNavigation();

    const title = route.params.title;
    const url = route.params.url;

    useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: true,
            headerLeft: () => <Entypo onPress={() => navigation.goBack()} name="chevron-left" size={24} color="white" />,
            headerTitle: title,
        });
    }, [navigation]);

    return (
        <View style={{flex: 1}}>
            <RNWebView style={{flex: 1}} source={{ uri: url }} />  
        </View>
    );
}