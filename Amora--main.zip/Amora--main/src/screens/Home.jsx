import React, { useRef, useEffect, useState } from "react";
import { Entypo, AntDesign } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { View, Image, StyleSheet, Text, TouchableOpacity } from "react-native";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { showToast, gererateId, addSibling } from "../helpers";
import {AstroCalculationModal, Loader} from "../components";
import { useAuth } from "../hooks";
import { gradients } from "../constants/colors";

import Swiper from "react-native-deck-swiper";
import firebase from "firebase";

import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";

dayjs.extend(relativeTime);

export default function Home() {
    const swiperRef = useRef();
    const animation = useRef(null);

    const [isModalVisible, setModalVisible] = useState(false);
    const [profiles, setProfiles] = useState([]);
    const [tappedUser, setTappedUser] = useState(null);

    const { user } = useAuth();

    const navigation = useNavigation();

    useEffect(() => {
        let unsub;

        const fetchCards = async () => {
            try {
                const passesSnapshot = await firebase
                    .firestore()
                    .collection("users")
                    .doc(user.uid)
                    .collection("passes")
                    .get();

                const swipesSnapshot = await firebase
                    .firestore()
                    .collection("users")
                    .doc(user.uid)
                    .collection("swipes")
                    .get();

                const passes = passesSnapshot.docs.map((doc) => doc.id);
                const swipes = swipesSnapshot.docs.map((doc) => doc.id);

                const passedUserIds = passes.length > 0 ? passes : ["test"];
                const swipedUserIds = swipes.length > 0 ? swipes : ["test"];

                unsub = firebase
                    .firestore()
                    .collection("users")
                    .where("uid", "not-in", [...passedUserIds, ...swipedUserIds])
                    .onSnapshot((snapshot) => {
                        setProfiles(
                            snapshot.docs
                                .filter((doc) => doc.id !== user.uid)
                                .map((doc) => ({
                                    id: doc.id,
                                    ...doc.data(),
                                }))
                        );
                    });
            } catch (err) {
                console.log(err.message);
                showToast("Something went wrong.");
            }
        };

        fetchCards();

        return () => {
            unsub();
        };
    }, []);

    const toggleModal = () => {
        setModalVisible(!isModalVisible);
    };

    const swipeLeft = async (cardIndex) => {
        if (!profiles[cardIndex]) return;

        const userSwiped = profiles[cardIndex];
        console.log("You swiped PASS on user", userSwiped.displayName);

        try {
            await firebase
                .firestore()
                .collection("users")
                .doc(user.uid)
                .collection("passes")
                .doc(userSwiped.id)
                .set(userSwiped);
        } catch (err) {
            console.log(err.message);
            showToast("Something went wrong.");
        }
    };

    const swipeRight = async (cardIndex) => {
        if (!profiles[cardIndex]) return;

        const userSwiped = profiles[cardIndex];
        console.log("You swiped on user", userSwiped.displayName);

        try {
            //check if the user has swiped on you
            const snapshot = await firebase
                .firestore()
                .collection("users")
                .doc(userSwiped.id)
                .collection("swipes")
                .doc(user.uid)
                .get();

            if (snapshot.exists) {
                //the user has matched with you before you matched with them
                //CREATE A MATCH
                console.log("Hooray! You just matched with", userSwiped.displayName);

                await firebase
                    .firestore()
                    .collection("users")
                    .doc(user.uid)
                    .collection("swipes")
                    .doc(userSwiped.id)
                    .set(userSwiped);

                await firebase
                    .firestore()
                    .collection("matches")
                    .doc(gererateId(user.uid, userSwiped.id))
                    .set({
                        users: {
                            [user.uid]: user,
                            [userSwiped.id]: userSwiped,
                        },
                        usersMatched: [user.uid, userSwiped.id],
                        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                    });

                navigation.navigate("Match", { userSwiped });
            } else {
                //create the first interaction between the 2 people
                await firebase
                    .firestore()
                    .collection("users")
                    .doc(user.uid)
                    .collection("swipes")
                    .doc(userSwiped.id)
                    .set(userSwiped);
            }
        } catch (err) {
            console.log(err.message);
            showToast("Something went wrong.");
        }
    };

    const onTapCard = (cardIndex) => {
        if (!profiles[cardIndex]) return; 
        
        setTappedUser(profiles[cardIndex]);
        toggleModal();
    };

    return (
        <View style={{ flex: 1 }}>
            <View style={{ flex: 1 }}>
                <Swiper
                    ref={swiperRef}
                    animateCardOpacity
                    containerStyle={{ backgroundColor: "transparent" }}
                    overlayLabels={{
                        left: {
                            title: "NOPE",
                            style: {
                                label: {
                                    textAlign: "right",
                                    color: "red",
                                },
                            },
                        },
                        right: {
                            title: "MATCH",
                            style: {
                                label: {
                                    color: "#4DED30",
                                },
                            },
                        },
                    }}
                    onSwipedLeft={(cardIndex) => {
                        console.log("Swipe PASS");
                        swipeLeft(cardIndex);
                    }}
                    onSwipedRight={(cardIndex) => {
                        console.log("Swipe MATCH");
                        swipeRight(cardIndex);
                    }}
                    cards={profiles}
                    cardIndex={0}
                    verticalSwipe={false}
                    onTapCard={onTapCard}
                    stackSize={5}
                    renderCard={(card) =>
                        card ? (
                            <View key={card.id} style={styles.cardWrapper}>
                                <Image source={{ uri: card.photoURL }} style={styles.cardImage} />

                                <View style={[styles.cardWhiteWrapper, styles.cardShadow]}>
                                    <View>
                                        <Text style={styles.cardUsername}>{card.displayName}</Text>
                                        <Text style={styles.cardUserJob}>{card?.shortBio}</Text>
                                    </View>

                                    <Text style={styles.cardUserAge}>{dayjs(card.birthdate.toDate()).fromNow(true).split(" ")[0]}</Text>
                                </View>
                            </View>
                        ) : (
                            <View style={[styles.noCardsWrapper, styles.cardShadow]}>
                                <Text style={styles.noProfilesTxt}>No more profiles at the moment</Text>
                                <Image
                                    style={styles.sadEmoji}
                                    source={{ uri: "https://links.papareact.com/6gb" }}
                                />
                            </View>
                        )
                    }
                />
            </View>

            <View style={styles.btnsWrapper}>
                <TouchableOpacity
                    onPress={() => swiperRef.current.swipeLeft()}
                    style={[styles.btnWrapper, { backgroundColor: "#ff1717" }]}>
                    <Entypo name="cross" color="#770707" size={28} />
                </TouchableOpacity>

                <TouchableOpacity
                    onPress={() => swiperRef.current.swipeRight()}
                    style={[styles.btnWrapper, { backgroundColor: "#2efa00" }]}>
                    <AntDesign name="heart" color="#03680d" size={21} />
                </TouchableOpacity>
            </View>

           
            <AstroCalculationModal 
                tappedUser={tappedUser} 
                isVisible={isModalVisible} 
                setIsVisible={setModalVisible} 
            />
       
        </View>
    );
}

const styles = StyleSheet.create({
    cardWrapper: {
        position: "relative",
        backgroundColor: "white",
        height: hp("60%"),
        borderRadius: 15,
    },
    noCardsWrapper: {
        position: "relative",
        backgroundColor: "white",
        height: hp("60%"),
        borderRadius: 15,
        alignItems: "center",
        justifyContent: "center",
    },
    btnsWrapper: {
        flexDirection: "row",
        marginBottom: 30,
        justifyContent: "space-evenly",
    },
    btnWrapper: {
        alignItems: "center",
        justifyContent: "center",
        width: 50,
        height: 50,
        borderRadius: 25,
    },
    cardShadow: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.2,
        shadowRadius: 1.41,
        elevation: 2,
    },
    cardWhiteWrapper: {
        position: "absolute",
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 15,
        paddingVertical: 5,
        bottom: 0,
        backgroundColor: "white",
        width: "100%",
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
        height: 60,
    },
    cardUsername: {
        fontSize: 18,
        fontWeight: "bold",
    },
    cardUserJob: {
        fontSize: 13,
        marginTop: 2,
    },
    cardUserAge: {
        fontSize: 20,
        fontWeight: "bold",
    },
    cardImage: {
        position: "absolute",
        top: 0,
        width: "100%",
        height: "100%",
        borderRadius: 15,
    },
    sadEmoji: {
        width: 80,
        height: 80,
    },
    noProfilesTxt: {
        fontSize: 19,
        fontWeight: "600",
        marginBottom: 15,
        color: gradients.primary[1],
    },
});
