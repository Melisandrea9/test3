import React, { useState, useEffect, useCallback, useRef } from "react";
import { LinearGradient } from "expo-linear-gradient";
import { Feather } from "@expo/vector-icons";
import { View, Text, StyleSheet, TextInput, ImageBackground, TouchableOpacity, Platform, ActionSheetIOS } from "react-native";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { useAuth } from "../hooks";
import { AndroidModal, Button, Loader } from "../components";
import { gradients } from "../constants/colors";
import { addSibling, chooseImageAsync, destroySibling, showToast, takePhotoAsync, uploadToStorage } from "../helpers";

import * as regex from "../constants/regex";
import firebase from "firebase";

const Input = ({ label, value, onChangeText, ...rest }) => {
    const [hasFocus, setHasFocus] = useState(false);

    return (
        <View>
            <Text style={styles.inputLabel}>{label}</Text>
            <TextInput
                {...rest}
                onBlur={() => setHasFocus(false)}
                onFocus={() => setHasFocus(true)}
                value={value}
                onChangeText={onChangeText}
                style={[styles.input, { borderBottomColor: hasFocus ? gradients.primary[1] : "gray" }]}
            />
        </View>
    );
};

export default function UpdateProfile() {
    const { user, setUser } = useAuth();

    const refRBSheet = useRef();

    const [profileImage, setProfileImage] = useState(user.photoURL);

    const [updateForm, setUpdateForm] = useState({
        username: user.displayName,
        email: user.email,
        shortBio: user.shortBio,
        password: "••••••",
        confirmPassword: "••••••",
    });

    const [isValid, setIsValid] = useState({
        username: false,
        email: false,
        password: false
    });

    const [error, setError] = useState("");

    useEffect(() => {
        setIsValid((state) => ({
            ...state,
            username: regex.username.test(updateForm.username),
            email: regex.email.test(updateForm.email),
            password: updateForm.password === updateForm.confirmPassword
        }));
    }, [updateForm, setIsValid]);

    useEffect(() => {
        const index = Object.values(isValid).findIndex((el) => !el);
        if (index === -1) {setError("No changes have been made");}
        if (index === 0) {setError("Username should be minimum 3 chars, maximum 15 chars");}
        if (index === 1) {setError("Email format is invalid");}
        if (index === 2) {setError("Passwords don't match");}
    }, [isValid]);

    const handleChange = useCallback(
        (value) => {
            setUpdateForm((state) => ({...state, ...value}));
        },
        [setUpdateForm],
    );

    const onCameraIconPress = () => {
        if (Platform.OS === "ios") {
            ActionSheetIOS.showActionSheetWithOptions(
                {
                    title: "Change profile picture",
                    options: ["Take from Camera", "Choose from Gallery", "Cancel"],
                    cancelButtonIndex: 2,
                },
                async (i) => {
                    if (i === 0) {
                        const localPhoto = await takePhotoAsync();
                        setProfileImage(localPhoto);
                    } else if (i === 1) {
                        const localImage = await chooseImageAsync();
                        setProfileImage(localImage);
                    }
                },
            );
        } else {
            addSibling(
                <AndroidModal 
                    options={[
                        {
                            title: "Take from Camera",
                            icon: require("../../assets/photo.png"),
                            callback: async () => {
                                const localPhoto = await takePhotoAsync();
                                setProfileImage(localPhoto);
                            }
                        },
                        {
                            title: "Choose from Gallery",
                            icon: require("../../assets/gallery.png"),
                            callback: async () => {
                                const localImage = await chooseImageAsync();
                                setProfileImage(localImage);
                            }
                        },
                    ]}
                    title={"Change profile picture"} 
                    ref={refRBSheet}
                />
            );
        }
    };

    const onUpdatePress = async () => {
        const isLocal = profileImage.split(":")[0] === "file"; 
        if (isLocal) {
            addSibling(<Loader />);
            try {
                const remoteURL = await uploadToStorage(profileImage, "photos"); 
                await firebase.auth().currentUser.updateProfile({
                    photoURL: remoteURL,
                });
                await firebase.firestore().collection("users").doc(user.uid).update({
                    photoURL: remoteURL, 
                });
                setProfileImage(remoteURL);
                setUser((value) => ({...value, photoURL: remoteURL}));
                alert("Profile picture sucessfully updated");
            } catch (err) {
                showToast(err.message); 
            } finally {
                destroySibling();
            }
        }
        if (isValid["username"] && (updateForm.username !== user.displayName)) {
            try {
                await firebase.auth().currentUser.updateProfile({
                    displayName: updateForm.username
                });
                await firebase.firestore().collection("users").doc(user.uid).update({
                    displayName: updateForm.username 
                });
                setUser((value) => ({...value, displayName: updateForm.username }));
                alert("Username sucessfully updated");
            } catch (err) {
                showToast(err.message);
            }
        } else if (isValid["email"] && (updateForm.email !== user.email)) {
            try {
                await firebase.auth().currentUser.updateEmail(updateForm.email);
                await firebase.firestore().collection("users").doc(user.uid).update({
                    email: updateForm.email 
                });
                setUser((value) => ({...value, email: updateForm.email}));
                alert("Email sucessfully updated");
            } catch (err) {
                showToast(err.message);
            }
        } else if (updateForm.shortBio) {
            try {
                await firebase.firestore().collection("users").doc(user.uid).update({
                    shortBio: updateForm.shortBio 
                });
                setUser((value) => ({...value, shortBio: updateForm.shortBio}));
                alert("Short bio sucessfully updated");
            } catch (err) {
                showToast(err.message);
            }
        } else if (isValid["password"] && (updateForm.password !== "••••••")) {
            try {
                await firebase.auth().currentUser.updatePassword(updateForm.password);
                alert("Password sucessfully updated");
            } catch (err) {
                showToast(err.message);
            }
        } else {
            showToast(error);
        }
    };

    return (
        <View style={{ flex: 1 }}>
            <View style={styles.infoWrapper}>
                <ImageBackground borderRadius={110/2} source={{ uri: profileImage }} style={styles.avatar}>
                    <TouchableOpacity onPress={onCameraIconPress} style={styles.cameraIconWrapper}>
                        <LinearGradient style={styles.cameraIconGradientWrapper} start={[0, 1]} end={[1, 0]} colors={gradients.primary}>
                            <Feather name="camera" size={15} color="white" />
                        </LinearGradient>
                    </TouchableOpacity>
                </ImageBackground>
                <Text style={styles.nameTxt}>{user.displayName}</Text>
                <Text style={styles.emailTxt}>{user.email}</Text>
            </View>

            <View style={{ marginTop: hp("5%"), marginHorizontal: 15 }}>
                <Input label="Username" value={updateForm.username} onChangeText={(value) => handleChange({username: value})} />
                <Input label="Email" value={updateForm.email} onChangeText={(value) => handleChange({email: value})} />
                <Input label="Short Bio" maxLength={25} value={updateForm.shortBio} onChangeText={(value) => handleChange({shortBio: value})} />
                <Input label="Password" value={updateForm.password} onChangeText={(value) => handleChange({password: value})} />
                <Input label="Confirm Password" value={updateForm.confirmPassword} onChangeText={(value) => handleChange({confirmPassword: value})} />
            </View>

            <Button onPress={onUpdatePress} title="Update Profile" style={styles.btn} />
        </View>
    );
}

const styles = StyleSheet.create({
    infoWrapper: {
        alignSelf: "center",
        alignItems: "center",
    },
    cameraIconWrapper: {
        backgroundColor: "#fff", 
        width: 30, 
        height: 30, 
        borderRadius: 15, 
        position: "absolute", 
        bottom: 0, 
        right: 0
    },
    cameraIconGradientWrapper: {
        flex: 1, 
        alignItems: "center", 
        justifyContent: "center", 
        margin: 2, 
        borderRadius: 15
    },
    avatar: {
        width: 110,
        height: 110,
        position: "relative",
        marginTop: hp("3%"),
        marginBottom: hp("1.5%"),
    },
    nameTxt: {
        color: "#fff",
        fontSize: 23,
        fontWeight: "600",
        marginBottom: 8,
    },
    emailTxt: {
        color: "gray",
        fontSize: 13,
        fontWeight: "600",
    },
    btn: {
        width: "94%",
        alignSelf: "center",
        marginTop: hp("5%"),
    },
    input: {
        borderBottomWidth: StyleSheet.hairlineWidth,
        paddingBottom: 10,
        color: "#fff",
        marginBottom: 20,
    },
    inputLabel: {
        fontWeight: "600",
        color: "gray",
        marginBottom: 12,
    },
});
