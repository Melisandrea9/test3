import React, { useState, useCallback } from "react";
import { View, Text, StyleSheet, Image, KeyboardAvoidingView, Keyboard } from "react-native";
import {
    heightPercentageToDP as hp,
    widthPercentageToDP as wp,
} from "react-native-responsive-screen";
import { Breaker, Button, Input, Loader } from "../components";
import { addSibling, destroySibling, showToast } from "../helpers";

import firebase from "firebase";

export default function Login({ navigation }) {
    const [loginForm, setLoginForm] = useState({
        email: "",
        password: "" ,
    });

    const handleChange = useCallback(
        (value) => {
            setLoginForm((state) => ({...state, ...value}));
        },
        [setLoginForm],
    );

    const login = useCallback(async() => {
        Keyboard.dismiss();
        addSibling(<Loader />);
        try {
            await firebase.auth().signInWithEmailAndPassword(loginForm.email, loginForm.password);
        } catch (err) {
            console.log(err.message);
            showToast(err.message);
        } finally {
            destroySibling();
        }
        
    }, [loginForm]);

    return (
        <KeyboardAvoidingView
            keyboardVerticalOffset={-100}
            enabled
            behavior="position"
            style={styles.container}>
            {/* Logo */}
            <Image style={styles.image} resizeMode="contain" source={require("../../assets/icon.png")} />

            {/* Register inputs */}
            <View style={styles.inputsWrapper}>
                <Input
                    value={loginForm.email}
                    autoCapitalize="none"
                    keyboardType="email-address"
                    onChangeText={(value) => handleChange({email: value})}
                    placeholder="Enter your email address"
                />
                <Input
                    secureTextEntry
                    value={loginForm.password}
                    onChangeText={(value) => handleChange({password: value})}
                    placeholder="Enter your password"
                />

                <Breaker />

                {/* Button */}
                <Button title="Login Now" onPress={login} />

                {/* footer txt */}
                <Text onPress={() => navigation.navigate("Register")} style={styles.text}>
          Don't have an account yet? Sign up
                </Text>
            </View>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#000",
    },
    inputsWrapper: {
        marginTop: "10%",
        padding: "4%",
    },
    text: {
        color: "#fbd3e9",
        shadowColor: "#bb377d",
        shadowOffset: { width: 4, height: 4 },
        shadowOpacity: 0.9,
        shadowRadius: 5,
        fontWeight: "bold",
        textAlign: "center",
        marginTop: hp("2%"),
        fontSize: hp("1.9%"),
    },
    image: {
        width: wp("100%"),
        height: hp("30%"),
        marginTop: hp("10%"),
    },
});
