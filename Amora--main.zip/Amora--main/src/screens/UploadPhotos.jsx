import React, {useLayoutEffect, useRef, useState} from "react";
import { AndroidModal, Loader } from "../components";
import { StyleSheet, Pressable, Platform, ActionSheetIOS, TouchableOpacity } from "react-native";
import { Entypo, AntDesign } from "@expo/vector-icons";
import { View, Image, Text } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";
import { addSibling, chooseImageAsync, destroySibling, multiUploadToStorage, showToast, takePhotoAsync } from "../helpers";
import { gradients } from "../constants/colors";

import firebase from "firebase";

const ImageBox = ({image, name, onImagePress, onEditPress, size }) => {
    return (
        <Pressable 
            style={[
                styles.imageWrapper,
                !image && {
                    borderWidth: StyleSheet.hairlineWidth, 
                    borderColor: "white"
                }, 
                size === "large" 
                    ? {height: hp("40%"), width: "100%"}
                    : {height: hp("13%"), width: "30%"}
            ]} 
            onPress={onImagePress}>
            {!image
                ? <AntDesign name="plus" size={28} color="white" />
                : <>
                    <Pressable onPress={onEditPress} style={styles.editIconWrapper}>
                        <Entypo name="edit" size={16} color="white" />
                    </Pressable>
                    <Text style={styles.nameTxt}>{name}</Text>
                    <Image 
                        style={styles.mainImage} 
                        source={{uri: image}} 
                    />
                </> 
            }
        </Pressable>
    );
};

export default function UploadPhotos() {
    const route = useRoute();
    const navigation = useNavigation();
    const data = route.params.data;

    const refRBSheet = useRef();

    const [images, setImages] = useState([]);

    useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: true,
            headerLeft: () => <Entypo onPress={() => navigation.goBack()} name="chevron-left" size={24} color="white" />,
            headerTitle: "Photos",
        });
    }, [navigation]);

    const onImagePress = () => {
        if (Platform.OS === "ios") {
            ActionSheetIOS.showActionSheetWithOptions(
                {
                    title: "Add photo",
                    options: ["Take from Camera", "Choose from Gallery", "Cancel"],
                    cancelButtonIndex: 2,
                },
                async (i) => {
                    if (i === 0) {
                        const localPhoto = await takePhotoAsync();
                        setImages((prev) => [...prev, localPhoto]);
                    } else if (i === 1) {
                        const localImage = await chooseImageAsync();
                        setImages((prev) => [...prev, localImage]);
                    }
                },
            );
        } else {
            addSibling(
                <AndroidModal
                    options={[
                        {
                            title: "Take from Camera",
                            icon: require("../../assets/photo.png"),
                            callback: async () => {
                                const localPhoto = await takePhotoAsync();
                                setImages((prev) => [...prev, localPhoto]); 
                            }
                        },
                        {
                            title: "Choose from Gallery",
                            icon: require("../../assets/gallery.png"),
                            callback: async () => {
                                const localImage = await chooseImageAsync();
                                setImages((prev) => [...prev, localImage]);
                            }
                        },
                    ]}  
                    title={"Add Photo"} 
                    ref={refRBSheet} 
                />
            );
        }
    };

    const onEditPress = (imageIndex) => {
        if (Platform.OS === "ios") {
            ActionSheetIOS.showActionSheetWithOptions(
                {
                    title: "Edit photo",
                    options: imageIndex > 0 
                        ? ["Take from Camera", "Choose from Gallery", "Delete photo", "Set as default", "Cancel"]
                        : ["Take from Camera", "Choose from Gallery", "Delete photo", "Cancel"],
                    cancelButtonIndex: imageIndex > 0 ? 4 : 3
                },  
                async (i) => {
                    if (i === 0) {
                        const localPhoto = await takePhotoAsync();
                        const copy = [...images];
                        copy.splice(imageIndex, 1, localPhoto);
                        setImages(copy);
                    } else if (i === 1) {
                        const localImage = await chooseImageAsync(); 
                        const copy = [...images];
                        copy.splice(imageIndex, 1, localImage);
                        setImages(copy);
                    } else if (i === 2) {
                        setImages(images.filter((_, i) => i !== imageIndex));
                    } else if (i === 3) {
                        const copy = [...images];
                        const element = copy[imageIndex];
                        copy.splice(imageIndex, 1);
                        copy.splice(0, 0, element);
                        setImages(copy);
                    }
                },
            );
        } else {
            addSibling(
                <AndroidModal
                    options={[
                        {
                            title: "Take from Camera",
                            icon: require("../../assets/photo.png"),
                            callback: async () => {
                                const localPhoto = await takePhotoAsync();
                                const copy = [...images];
                                copy.splice(imageIndex, 1, localPhoto);
                                setImages(copy); 
                            }
                        },
                        {
                            title: "Choose from Gallery",
                            icon: require("../../assets/gallery.png"),
                            callback: async () => {
                                const localImage = await chooseImageAsync(); 
                                const copy = [...images];
                                copy.splice(imageIndex, 1, localImage);
                                setImages(copy);
                            }
                        },
                        {
                            title: "Delete photo",
                            icon: require("../../assets/delete.png"),
                            callback: async () => {
                                setImages(images.filter((_, i) => i !== imageIndex));
                            }
                        },
                        imageIndex > 0 ? {
                            title: "Set as default",
                            icon: require("../../assets/up.png"),
                            callback: async () => {
                                const copy = [...images];
                                const element = copy[imageIndex];
                                copy.splice(imageIndex, 1);
                                copy.splice(0, 0, element);
                                setImages(copy);
                            }
                        } : null, 
                    ]}  
                    title={"Edit Photo"} 
                    ref={refRBSheet} 
                />
            );
        }  
    };

    const onNextPress = async () => {
        addSibling(<Loader />);
        try {
            const remoteURLS = await multiUploadToStorage(images, "photos");
            const {user} = await firebase.auth().createUserWithEmailAndPassword(data.registration.email, data.registration.password);
            await firebase.firestore().collection("users").doc(user.uid).set({
                uid: user.uid,
                email: user.email,
                displayName: data.registration.username,
                photoURL: remoteURLS[0],
                ...(remoteURLS.length > 1 && { extraPhotos: remoteURLS.slice(1)}),
                shortBio: data.shortBio,
                birthplace: data.birthplace,
                birthdate: data.birthdate,
                birthtime: data.birthtime
            });
            await user.updateProfile({
                photoURL: remoteURLS[0],
                displayName: data.registration.username,
            });
        } catch (err) {
            console.log(err);
            showToast(err.message);
        } finally {
            destroySibling(); 
        } 
    };

    return (
        <View style={styles.container}>
            <ImageBox 
                image={images?.[0]} 
                size="large"
                name={data.registration.username} 
                onImagePress={onImagePress} 
                onEditPress={() => onEditPress(0)}
            />

            <View style={styles.extraImagesWrapper}>
                <ImageBox 
                    onEditPress={() => onEditPress(1)} 
                    image={images?.[1]} 
                    size="small" 
                    onImagePress={onImagePress} 
                />
                <ImageBox 
                    onEditPress={() => onEditPress(2)} 
                    image={images?.[2]} 
                    size="small" 
                    onImagePress={onImagePress} 
                />
                <ImageBox 
                    onEditPress={() => onEditPress(3)} 
                    image={images?.[3]} 
                    size="small" 
                    onImagePress={onImagePress} 
                />
            </View>

            <TouchableOpacity 
                onPress={onNextPress}
                disabled={!images.length > 0} 
                style={styles.nextBtnWrapper}>
                <Text style={{color: "#bb377d"}}>NEXT</Text>
                <Entypo name="chevron-right" size={24} color="#bb377d" />
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 15
    },
    extraImagesWrapper: {
        flexDirection: "row", 
        marginTop: 15, 
        justifyContent: "space-between"
    },
    imageWrapper: {
        position: "relative", 
        alignItems: "center", 
        justifyContent: "center", 
        borderRadius: 5, 
    },
    editIconWrapper: {
        width: 28, 
        height: 28, 
        zIndex: 1, 
        top: -10, 
        right: -10, 
        position: "absolute", 
        backgroundColor: gradients.primary[1], 
        borderRadius: 28/2, 
        alignItems: "center", 
        justifyContent: "center"
    },
    nextBtnWrapper: {
        flexDirection: "row", 
        alignItems: "center", 
        position: "absolute", 
        bottom: "4.5%", 
        right: "3%"
    },
    mainImage: {
        width: "100%", 
        height: "100%", 
        borderRadius: 5,
        flex: 1
    },
    nameTxt: {
        color: "white", 
        position: "absolute", 
        zIndex: 1, 
        left: 15, 
        bottom: 15, 
        fontSize: 23, 
        fontWeight: "600"
    }
});