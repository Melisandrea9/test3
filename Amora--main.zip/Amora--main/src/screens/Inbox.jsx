import React, { useLayoutEffect, useEffect, useState } from "react";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from "react-native";
import { getMatchedUserInfo } from "../helpers";
import { useAuth } from "../hooks";

import dayjs from "dayjs";
import firebase from "firebase";
import { gradients } from "../constants/colors";

const ChatRow = ({ matchDetails }) => {
    const [matchedUserInfo, setMatchedUserInfo] = useState(null);
    const [lastMessage, setLastMessage] = useState(null);

    const { user } = useAuth();
    const navigation = useNavigation();

    useEffect(() => {
        setMatchedUserInfo(getMatchedUserInfo(matchDetails.users, user.uid));
    }, [matchDetails, user]);

    useEffect(() => 
        firebase
            .firestore()
            .collection("matches")
            .doc(matchDetails.id)
            .collection("messages")
            .orderBy("createdAt", "desc")
            .onSnapshot((snapshot) => setLastMessage(snapshot.docs[0]?.data()))
    , []);

    return (
        <TouchableOpacity
            onPress={() => navigation.navigate("Message", { matchDetails })}
            style={styles.chatRowWrapper}>
            <View style={styles.chatRowNestedWrapper}>
                <Image source={{ uri: matchedUserInfo?.photoURL }} style={styles.image} />

                <View style={styles.infoWrapper}>
                    <Text style={styles.chatRowUsername}>{matchedUserInfo?.displayName}</Text>
                    <Text style={styles.chatRowLastMsg}>{lastMessage?.text || "Say Hi 👋"}</Text>
                </View>

                {lastMessage?.createdAt && (
                    <Text style={styles.chatRowMsgTime}>{dayjs(lastMessage.createdAt.toDate()).format("HH:mm A")}</Text>
                )}
            </View>  
        </TouchableOpacity>
    );
};

export default function Inbox() {
    const [matches, setMatches] = useState([]);

    const { user } = useAuth();

    const navigation = useNavigation();

    useLayoutEffect(() => {
        navigation.setOptions({
            headerLeft: () => <Text style={styles.editBtn}>Edit</Text>,
            headerRight: () => <Ionicons name="filter" size={24} color="white" />,
        });
    }, [navigation]);

    useEffect(
        () =>
        //fetch all matches
            firebase
                .firestore()
                .collection("matches")
                .where("usersMatched", "array-contains", user.uid)
                .onSnapshot((snapshot) =>
                    setMatches(
                        snapshot.docs.map((doc) => ({
                            id: doc.id,
                            ...doc.data(),
                        }))
                    )
                ),
        []
    );

    return (
        <View style={{ flex: 1 }}>
            {matches.length > 0 ? (
                <FlatList
                    data={matches.reverse()}
                    keyExtractor={(item) => item.id}
                    renderItem={({ item }) => <ChatRow matchDetails={item} />}
                />
            ) : (
                <Text style={styles.noMatchesTxt}>Your soul mate is out there  <Image style={{width: 20, height: 20}} source={require("../../assets/cool-emoji.png")} /></Text>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    chatRowWrapper: {
        backgroundColor: "#121212",
        width: "100%",
        padding: 12,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: "#2a2a2a",
    },
    chatRowNestedWrapper: {
        position: "relative", 
        flexDirection: "row", 
        alignItems: "center"
    },
    infoWrapper: {
        marginLeft: 15,
    },
    chatRowUsername: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#fff",
        marginBottom: 5,
    },
    chatRowLastMsg: {
        fontSize: 12,
        color: "#fff",
    },
    chatRowMsgTime: {
        position: "absolute",
        right: 0,
        color: "gray",
        fontSize: 12,
    },
    image: {
        width: 50,
        height: 50,
        borderRadius: 50 / 2,
    },
    editBtn: {
        color: gradients.primary[1],
        fontSize: 16,
        fontWeight: "500",
    },
    noMatchesTxt: {
        alignSelf: "center",
        fontSize: 20,
        color: gradients.primary[1],
        fontWeight: "500",
        marginTop: "80%",
    },
});
