import {
    MaterialCommunityIcons,
    FontAwesome5,
    Entypo,
    MaterialIcons,
    AntDesign,
} from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import firebase from "firebase";
import React from "react";
import { View, Text, Image, StyleSheet, Pressable } from "react-native";
import { heightPercentageToDP as hp } from "react-native-responsive-screen";

import { Button } from "../components";
import { gradients } from "../constants/colors";
import { showToast } from "../helpers";
import { useAuth } from "../hooks";

const ProfileRow = ({ text, iconComponent, onPress }) => {
    return (
        <Pressable onPress={onPress} style={styles.profileRowContainer}>
            <LinearGradient
                style={styles.gradientWrapper}
                start={[0, 1]}
                end={[1, 0]}
                colors={gradients.primary}>
                {iconComponent}
            </LinearGradient>

            <Text style={styles.profileRowTxt}>{text}</Text>

            <Entypo name="chevron-right" size={26} color="gray" />
        </Pressable>
    );
};

export default function Profile() {
    const navigation = useNavigation();

    const { user } = useAuth();

    const logout = async () => {
        try {
            await firebase.auth().signOut();
        } catch (err) {
            console.log(err.message);
            showToast("Something went wrong.");
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.infoWrapper}>
                <Image source={{ uri: user.photoURL }} style={styles.avatar} />

                <View style={styles.nameEmailWrapper}>
                    <Text style={styles.nameTxt}>{user.displayName}</Text>
                    <Text style={styles.emailTxt}>{user.email}</Text>
                </View>

                <MaterialCommunityIcons
                    onPress={() => navigation.navigate("UpdateProfile")}
                    name="account-edit-outline"
                    size={28}
                    color="gray"
                />
            </View>

            <View>
                <Text style={{ color: "gray", fontWeight: "600", marginBottom: 7 }}>Dashboard</Text>
                <ProfileRow
                    iconComponent={<FontAwesome5 name="user-cog" size={20} color="white" />}
                    text="User Information"
                    onPress={() => navigation.navigate("UpdateProfile")}
                />
                <ProfileRow
                    iconComponent={<MaterialIcons name="privacy-tip" size={26} color="#fff" />}
                    text="Terms of service"
                    onPress={() => {}}
                />
                <ProfileRow
                    iconComponent={<MaterialIcons name="privacy-tip" size={26} color="#fff" />}
                    text="Privacy Policy"
                    onPress={() => {}}
                />
                <ProfileRow
                    iconComponent={<AntDesign name="customerservice" size={26} color="#fff" />}
                    text="Costumer Support"
                    onPress={() => {}}
                />
            </View>

            <Button onPress={logout} title="Logout" style={styles.btn} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginHorizontal: 30,
    },
    profileRowContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginVertical: 10,
    },
    infoWrapper: {
        marginTop: 30,
        marginBottom: 50,
        flexDirection: "row",
        alignItems: "center",
    },
    gradientWrapper: {
        width: 45,
        height: 45,
        borderRadius: 45 / 2,
        alignItems: "center",
        justifyContent: "center",
    },
    nameEmailWrapper: {
        flex: 1,
        alignSelf: "center",
    },
    nameTxt: {
        color: "#fff",
        fontSize: 23,
        marginBottom: 6,
        fontWeight: "600",
    },
    emailTxt: {
        color: "gray",
    },
    avatar: {
        width: 105,
        height: 105,
        borderRadius: 105 / 2,
        marginRight: hp("2.5%"),
    },
    btn: {
        marginTop: hp("6%"),
    },
    profileRowTxt: {
        width: "75%",
        color: "#fff",
        fontSize: 18,
        fontWeight: "600",
        marginLeft: hp("2.5%"),
    },
});
