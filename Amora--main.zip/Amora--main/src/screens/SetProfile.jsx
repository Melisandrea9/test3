import React, {useLayoutEffect, useEffect, forwardRef, useRef, useMemo, useState} from "react";
import { View, Text, TextInput, StyleSheet, Pressable, Platform, TouchableOpacity, Keyboard } from "react-native";
import { Entypo } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";

import DateTimePicker from "@react-native-community/datetimepicker";
import RBSheet from "react-native-raw-bottom-sheet";

import dayjs from "dayjs";

const SetUpOption = ({type="button", title, value, onPress, ...rest}) => {
    return (
        <Pressable onPress={onPress}>
            <Text style={styles.optionTitle}>{title}</Text>
            {type === "button" ?  (
                <View style={styles.optionValueWrapper}>
                    <Text style={styles.optionValue}>{value}</Text> 
                </View>
            )
                : (
                    <TextInput style={styles.input} value={value} {...rest} /> 
                )
            }
        </Pressable>
    );  
};

const DatePickerModal = forwardRef(({
    showPicker,
    value,
    onChange,
    type,
}, ref) => {
    if (Platform.OS === "android") {
        return showPicker && (
            <DateTimePicker
                value={value}
                mode={type === "date" ? "date" : "time"}
                display={"default"}
                is24Hour={true}
                onChange={onChange}
            />
        );
    } else {
        return (
            <RBSheet
                ref={ref}
                animationType="slide"
                height={300}
                openDuration={250}
            >
                <>
                    <Text 
                        onPress={() => ref.current?.close()} 
                        style={styles.doneBtn}>
                    Done
                    </Text>
                    <DateTimePicker
                        value={value}
                        mode={type === "date" ? "date" : "time"}
                        display={"spinner"}
                        is24Hour={true}
                        themeVariant={"light"}
                        onChange={onChange}
                    />
                </>
            </RBSheet>
        ); 
    } 
});

export default function SetProfile() {

    const refRbSheet = useRef(null);

    const initialDate = useMemo(() => {
        return new Date("May 7, 2004 03:24:00");
    }, []);

    const initialTime = useMemo(() => {
        return new Date("May 7, 2004 03:24:00");
    }, []);

    const [keyboardVisible, setkeyboardVisible] = useState(false);

    const [shortBio, setShortBio] = useState("");
    const [showPicker, setShowPicker] = useState(false);
    const [pickerMode, setPickerMode] = useState("date");
    const [birthdate, setBirthdate] = useState(initialDate);
    const [birthtime, setBirthtime] = useState(initialTime);

    const navigation = useNavigation();
    const route = useRoute();

    const registration = route.params.registration;
    const birthplace = route.params?.birthplace;

    useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: true,
            headerLeft: () => <Entypo onPress={() => navigation.goBack()} name="chevron-left" size={24} color="white" />,
            headerTitle: "Tell us about yourself",
        });
    }, [navigation]);

    useEffect(() => {
        const keyboardDidShowListener = Keyboard.addListener(
            "keyboardDidShow",
            () => {
                setkeyboardVisible(true);
            }
        );

        const keyboardDidHideListener = Keyboard.addListener(
            "keyboardDidHide",
            () => {
                setkeyboardVisible(false);
            }
        );

        return () => {
            keyboardDidHideListener.remove();
            keyboardDidShowListener.remove();
        };
    }, []);

    const onPickerValueChange = (e, val) => {
        if (pickerMode === "date") {
            setBirthdate(val);
        } else {
            setBirthtime(val);
        }

        if (Platform.OS === "android") {
            setShowPicker(false);
        }
    };

    const onNextPress = async () => {
        navigation.navigate("UploadPhotos", {data: {
            registration,
            shortBio,
            birthplace,
            birthdate,
            birthtime  
        }});
    };

    return (
        <View style={styles.container}>
            <View style={{flex: 1, position: "relative"}}>
                <SetUpOption 
                    type="input"
                    value={shortBio}
                    maxLength={25}
                    onChangeText={setShortBio}
                    onPress={() => {}} 
                    title={"Short Bio"} 
                />
                <SetUpOption 
                    value={birthplace?.place} 
                    onPress={() => navigation.navigate("Modal", {registration})} 
                    title={"My birthplace"} 
                /> 
                <SetUpOption 
                    value={initialDate !== birthdate && dayjs(birthdate).format("LL")} 
                    onPress={() => {
                        setPickerMode("date");
                        Platform.OS === "ios" ? refRbSheet.current?.open() : setShowPicker(true);
                    }} 
                    title={"My date of birth"} 
                /> 
                <SetUpOption 
                    value={initialTime !== birthtime && dayjs(birthtime).format("LT")} 
                    onPress={() => {
                        setPickerMode("time");
                        Platform.OS === "ios" ? refRbSheet.current?.open() : setShowPicker(true);
                    }} 
                    title={"My time of birth"} 
                /> 

                <View style={styles.accuracyTxtWrapper}>
                    <Text style={[styles.accuracyTxt, {marginBottom: 2}]}>Your astrological calculations will be more accurate the closer</Text>
                    <Text style={styles.accuracyTxt}>your birth time is entered.</Text>
                </View>

                <DatePickerModal 
                    ref={refRbSheet} 
                    type={pickerMode} 
                    showPicker={showPicker}
                    onChange={onPickerValueChange}
                    value={pickerMode === "date" ? birthdate : birthtime}
                />

                {!keyboardVisible && (
                    <TouchableOpacity 
                        onPress={onNextPress}
                        disabled={!shortBio || !birthplace || (initialDate === birthdate) || (initialTime === birthtime)} 
                        style={styles.nextBtnWrapper}>
                        <Text style={{color: "#bb377d"}}>NEXT</Text>
                        <Entypo name="chevron-right" size={24} color="#bb377d" />
                    </TouchableOpacity>
                )}
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1, 
        paddingHorizontal: 10, 
        paddingVertical: 50
    },
    nextBtnWrapper: {
        flexDirection: "row", 
        alignItems: "center", 
        position: "absolute", 
        bottom: 0, 
        right: 0
    },
    accuracyTxtWrapper: {
        width: "99%", 
        alignItems: "center"
    },
    accuracyTxt: {
        color: "gray", 
        fontSize: 12
    },
    optionValueWrapper: {
        alignItems: "center", 
        marginBottom: 25, 
        paddingBottom: 8, 
        borderBottomWidth: StyleSheet.hairlineWidth, 
        borderBottomColor: "#413f3f"
    },
    input: {
        marginBottom: 25,
        paddingBottom: 4, 
        borderBottomWidth: StyleSheet.hairlineWidth, 
        borderBottomColor: "#413f3f",
        fontSize: 21, 
        color: "white", 
        fontWeight: "600",
        textAlign: "center"
    },
    optionTitle: {
        color: "gray", 
        alignSelf: "center",
        fontSize: 15, 
        marginBottom: 12
    },
    optionValue: {
        fontSize: 21, 
        color: "white", 
        fontWeight: "600"
    },
    doneBtn: {
        alignSelf: "flex-end", 
        fontWeight: "500", 
        fontSize: 16, 
        color: "#045dac", 
        padding: 15
    }
});