import React, {useState} from "react";
import {Button} from "../components";
import { View, FlatList, SafeAreaView, StyleSheet, Text, Image, ScrollView } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { Entypo } from "@expo/vector-icons";
import { getAspectImage, getPlannetImage } from "../helpers";
import { gradients } from "../constants/colors";

import Accordion from "react-native-collapsible/Accordion";

const PlanetItem = (props) => {
    return (
        <View style={styles.contentItemWrapper}>
            <Image 
                style={styles.contentItemIcon} 
                source={getPlannetImage(props.name)} 
            />
            <Text style={styles.contentItemTxt}>{props.name} in {Math.round(props.norm_degree)}° {props.sign} {props.is_retro === "true" && "(r)"}</Text>
        </View>
    );
};

const AspectItem = (props) => {
    return (
        <View style={styles.contentItemWrapper}>
            <Image 
                style={styles.contentItemIcon} 
                source={getAspectImage(props.type)} 
            />
            <Text style={styles.contentItemTxt}>{props.first} {props.type} {props.second} <Text style={{color: gradients.primary[1]}}> orb: {Math.round(props.orb)} °</Text></Text>
        </View>
    );
};

export default function CalculationDetails() {
    const route = useRoute(); 
    const navigation = useNavigation();

    const {data} = route.params;
    
    const [activeSections, setActiveSections] = useState([]);
    const [active2Sections, setActive2Sections] = useState([]);

    console.log(data.slice(-1));

    return (
        <SafeAreaView style={styles.container}>
            <Image 
                resizeMode='contain' 
                style={styles.lettersImage} 
                source={require("../../assets/synastry-chart.png")} 
            />

            <Image
                resizeMode='contain' 
                source={require("../../assets/chart.png")}
                style={styles.chartImage} 
            />

            <ScrollView>
                <View style={styles.featureWrapper}>
                    <Image 
                        style={styles.featureIcon} 
                        source={require("../../assets/plannet.png")} 
                    />
                    <Text style={styles.featureTxt}>Plannets :</Text>
                </View>

                <Text style={styles.featureDescription}>You can think of the planets as symbolizing core parts of the human personality, and the signs as different colors of consciousness through which they filter.</Text>

                <Accordion
                    sections={data.slice(0,2)}
                    activeSections={activeSections}
                    renderHeader={(section) => (
                        <View style={styles.plannetHeaderWrapper}>
                            <Text style={styles.plannetHeaderTxt}>{section.title}</Text>
                            <Entypo name="chevron-right" size={24} color="white" />
                        </View>  
                    )}
                    renderContent={(section) => (
                        <FlatList
                            data={section.content}
                            keyExtractor={(item, index) => index.toString()}
                            renderItem={({item}) => <PlanetItem {...item} />} 
                        />
                    )}
                    onChange={setActiveSections}
                />

                <View style={[styles.featureWrapper, {marginTop: 20}]}>
                    <Image 
                        style={styles.featureIcon} 
                        source={require("../../assets/aspect.png")} 
                    />
                    <Text style={styles.featureTxt}>Aspects :</Text>
                </View>

                <Text style={styles.featureDescription}>The aspects describe the geometric angles between the planets. Each shape they produce has a different meaning. In a synastry chart, the aspects are the relationship between the two sets of planets.</Text>

                <Accordion
                    sections={data.slice(-1)}
                    activeSections={active2Sections}
                    renderHeader={(section) => (
                        <View style={styles.plannetHeaderWrapper}>
                            <Text style={styles.plannetHeaderTxt}>{section.title}</Text>
                            <Entypo name="chevron-right" size={24} color="white" />
                        </View>  
                    )}
                    renderContent={(section) => (
                        <FlatList
                            data={section.content}
                            keyExtractor={(item, index) => index.toString()}
                            renderItem={({item}) => <AspectItem {...item} />} 
                        />
                    )}
                    onChange={setActive2Sections}
                />

                <Button onPress={() => navigation.goBack()} title="Go back" style={{marginTop: 30}} />
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1, 
        marginHorizontal: 15
    },
    featureWrapper: {
        flexDirection: "row", 
        alignItems: "center", 
        marginVertical: 5
    },
    contentItemWrapper: {
        flexDirection: "row", 
        marginVertical: 5, 
        alignItems: "center"
    },
    plannetHeaderWrapper: {
        flexDirection: "row",
        marginVertical: 5, 
        alignItems: "center"
    },
    contentItemIcon: {
        width: 22, 
        height: 22, 
        marginRight: 10
    },
    contentItemTxt: {
        color: "white"
    },
    plannetHeaderTxt: {
        color: "white", 
        fontSize: 16, 
        marginRight: 4
    },
    lettersImage: {
        width: 230, 
        height: 100, 
        marginBottom: 10,
        alignSelf: "center"
    },
    featureIcon: {
        width: 25, 
        height: 25, 
        marginRight: 12
    },
    featureDescription: {
        color: "gray", 
        width: "90%", 
        marginBottom: 15
    },
    featureTxt: {
        color: "white", 
        fontSize: 16, 
        marginRight: 4, 
        textTransform: "uppercase", 
        fontWeight: "500"
    },
    chartImage: {
        width: 230, 
        height: 230, 
        marginBottom: 30,
        alignSelf: "center"
    }
});