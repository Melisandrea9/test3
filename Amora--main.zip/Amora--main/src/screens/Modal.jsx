import React, { useState } from "react";
import { View, Text, StyleSheet, Platform } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";

import HighlightText from "@sanar/react-native-highlight-text";

const PlaceRow = ({data, searchTerm}) => {
    const {main_text, secondary_text} = data.structured_formatting;

    return (
        <View style={{height: 30}}>
            <HighlightText
                style={{color: "white"}}
                highlightStyle={{ color: "gold" }}
                searchWords={[searchTerm]}
                textToHighlight={main_text}
            />
            <Text style={{color: "gray", fontSize: 13}}>{secondary_text}</Text>
        </View>
    );
};

export default function Modal() {
    const navigation = useNavigation();
    const route = useRoute();

    const registration = route.params.registration;

    const [searchTerm, setSearchTerm] = useState("");

    const onSelectBirthPlace = (data, details) => {
        const {main_text} = data.structured_formatting;

        navigation.navigate("SetProfile", {birthplace: {
            place: main_text,
            latitude: details.geometry.location.lat,
            longitude: details.geometry.location.lng
        }, registration});
    };

    return (
        <View style={styles.container}>
            <GooglePlacesAutocomplete
                enablePoweredByContainer={false}
                styles={{
                    container: {
                        flex: searchTerm ? 0.43 : 0
                    },
                    textInputContainer: {
                        padding: 10,
                    },
                    textInput: {
                        backgroundColor: "#17181d",
                        color: "white",
                        height: 44,
                        borderRadius: 5,
                        paddingVertical: 5,
                        paddingHorizontal: 10,
                        fontSize: 15,
                        flex: 1,
                    }, 
                    separator: {
                        height: 0,
                    }, 
                    row: {
                        backgroundColor: "transparent",
                    },               
                }}
                fetchDetails
                textInputProps={{
                    leftIcon: { type: "font-awesome", name: "chevron-left" },
                    placeholderTextColor: "#5f5f5f",
                    onChangeText: setSearchTerm,
                    errorStyle: { color: "red" },
                }}
                placeholder="Search"
                query={{
                    key: "AIzaSyBQ_3zEuol3vR4MREo55PApfdUDoseTPoc",
                    language: "en", // language of the results
                }}
                renderRightButton={() => (
                    <Text onPress={() => navigation.goBack()} style={styles.cancelBtn}>Cancel</Text>  
                )}
                renderRow={(data) => <PlaceRow searchTerm={searchTerm} data={data} />}
                onPress={onSelectBirthPlace}
                onFail={(error) => console.error(error)}
            />
            <Text 
                onPress={() => navigation.goBack()} 
                style={styles.poweredByTxt}>powered by Google</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        ...(Platform.OS === "android" && {marginTop: 15})
    },
    poweredByTxt: {
        color: "gray", 
        fontSize: 13, 
        alignSelf: "center", 
        fontWeight: "500", 
        marginVertical: 15
    },
    cancelBtn: {
        color: "white", 
        fontWeight: "500", 
        fontSize: 15, 
        marginLeft: 10, 
        alignSelf: "center"
    }
});