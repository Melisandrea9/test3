import dayjs from "dayjs";
import { Entypo, Feather } from "@expo/vector-icons";
import React, { useState, useEffect, useCallback, useLayoutEffect } from "react";
import { View, Text, SafeAreaView, Platform, StyleSheet, TouchableOpacity } from "react-native";
import { GiftedChat, Composer, Bubble, InputToolbar } from "react-native-gifted-chat";
//import { MESSAGES } from "../constants/mocks";
import { useNavigation, useRoute } from "@react-navigation/native";
import { showToast } from "../helpers";
import { useAuth } from "../hooks";

import firebase from "firebase";

export default function Message() {
    const [message, setMessage] = useState("");
    const [messages, setMessages] = useState([]);

    const navigation = useNavigation();
    const route = useRoute();

    const { matchDetails } = route.params;
    const { user } = useAuth();

    const matchedUserUID = matchDetails.usersMatched.filter((id) => id !== user.uid)[0];
    const matchedUser = matchDetails.users[matchedUserUID];

    useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: true,
            headerLeft: () => <Entypo onPress={() => navigation.goBack()} name="chevron-left" size={24} color="white" />,
            headerTitle: matchedUser.displayName,
            //headerRight: () => <Ionicons name="filter" size={24} color="white" />,
        });
    }, [navigation]);

    useEffect(() => 
        firebase.firestore().collection("matches").doc(matchDetails.id).collection("messages").orderBy("createdAt", "desc").onSnapshot((snapshot) => setMessages(
            snapshot.docs.map((doc) => ({
                _id: doc.id,
                ...doc.data(),
                createdAt: doc.data().createdAt.toDate(),
            })) 
        )),
    []);

    const handleSend = useCallback(
        async () => {
            try {
                await firebase.firestore().collection("matches").doc(matchDetails.id).collection("messages").add({
                    createdAt: dayjs().subtract(1, "m").toDate(),
                    text: message,
                    user: {
                        _id: user.uid,
                        name: user.displayName,
                        avatar: user.photoURL,
                    },
                });

                setMessage("");
            } catch (err) {
                showToast("Something went wrong.");
                console.log(err.message);
            } 
        },
        [setMessages, setMessage, message]
    );

    return (
        <SafeAreaView style={{ flex: 1 }}>
            <GiftedChat
                alignTop
                renderAvatarOnTop
                showUserAvatar
                messages={messages}
                text={message}
                onInputTextChanged={(text) => setMessage(text)}
                onSend={(messages) => handleSend(messages)}
                user={{ _id: user.uid, name: user.displayName, avatar: user.photoURL }}
                renderActions={() => (
                    <TouchableOpacity style={{alignSelf: "center", marginHorizontal: 15}}>
                        <Entypo name="image" size={20} color="white" />
                    </TouchableOpacity>
                )}
                renderComposer={(props) => (
                    <Composer
                        {...props}
                        textInputStyle={{
                            marginLeft: 0,
                            color: "gray",
                            paddingTop: Platform.OS === "android" ? 0 : 8,
                        }}
                    />
                )}
                renderInputToolbar={(props) => (
                    <InputToolbar
                        {...props}
                        optionTintColor="gray"
                        containerStyle={{
                            paddingTop: 0,
                            marginTop: 0,
                            marginBottom: 10,
                            borderColor: "gray",
                            borderRadius: 20,
                            borderWidth: StyleSheet.hairlineWidth,
                            backgroundColor: "transparent",
                        }}
                        renderSend={({ text }) => {
                            if (text?.length === 0) {
                                return null;
                            }

                            return (
                                <TouchableOpacity style={{alignSelf: "center", marginHorizontal: 15}} onPress={handleSend}>
                                    <Feather name="send" size={20} color="white" />
                                </TouchableOpacity>
                            );
                        }}
                    />
                )}
                renderBubble={(props) => (
                    <Bubble
                        {...props}
                        wrapperStyle={{
                            left: { backgroundColor: "transparent" },
                            right: { backgroundColor: "transparent" },
                        }}
                    />
                )}
                renderTime={(props) => (
                    <Text style={{fontSize: 13, marginVertical: 7, color: "white"}}>
                        {dayjs(props?.currentMessage?.createdAt).format("HH:mm A")}
                    </Text>
                )}
                renderMessageText={(props) => {
                    const isMine = props?.currentMessage?.user?._id === user?.uid;
                    return (
                        <View
                            style={{
                                borderRadius: 14,
                                padding: 12,
                                justifyContent: "center",
                                backgroundColor: isMine ? "#292C3A" : "white",
                            }}>
                            <Text style={{ color: isMine ? "white" : "black" }}>
                                {props?.currentMessage?.text}
                            </Text>
                        </View>
                    );
                }}
            />
        </SafeAreaView>
    );
}
