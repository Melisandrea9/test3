import React from "react";
import { useNavigation, useRoute } from "@react-navigation/native";
import { View, Text, StyleSheet, Image } from "react-native";
import { Button } from "../components";
import { useAuth } from "../hooks";

export default function Match() {
    const navigation = useNavigation();
    const { params } = useRoute();

    const { user } = useAuth();

    const { userSwiped } = params;

    return (
        <View style={styles.container}>
            <Image resizeMode="contain" style={styles.image} source={require("../../assets/match.png")} />

            <Text style={styles.txt}>You and {userSwiped.displayName} liked each other</Text>

            <View style={styles.row}>
                <Image style={styles.avatar} source={{ uri: user.photoURL }} />
                <Image style={styles.avatar} source={{ uri: userSwiped.photoURL }} />
            </View>

            <Button onPress={() => navigation.navigate("Inbox")} style={styles.btn} title="Send Message" />
            <Text onPress={() => navigation.goBack()} style={styles.goBackBtn}>
        Go back
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#000",
        alignItems: "center",
        paddingTop: "30%",
    },
    image: {
        width: "80%",
        height: "25%",
    },
    txt: {
        fontSize: 17,
        fontWeight: "500",
        color: "#fff",
    },
    row: {
        flexDirection: "row",
        width: "80%",
        justifyContent: "space-evenly",
        marginTop: "10%",
    },
    avatar: {
        width: 120,
        height: 120,
        borderRadius: 120 / 2,
    },
    btn: {
        marginTop: 50,
        marginBottom: 20,
        width: "85%",
    },
    goBackBtn: {
        color: "#fff",
        fontSize: 16,
        fontWeight: "600",
    },
});
