import React, {createContext, useContext, useEffect, useState} from "react";

import * as SplashScreen from "expo-splash-screen";

import firebase from "firebase";

const AuthContext = createContext({});

export const AuthProvider = ({children}) => {
    const [user, setUser] = useState(null);

    useEffect(() => 
        firebase.auth().onAuthStateChanged(async(authUser) => {
            if (authUser) {
                console.log(authUser);
                const snapshot = await firebase.firestore().collection("users").doc(authUser.uid).get();
                if (snapshot.exists) {
                    setUser({...snapshot.data()});  
                }
            } else {
                setUser(null);
            }

            await SplashScreen.hideAsync();
        })
    , []);

    return ( 
        <AuthContext.Provider value={{
            user: user,
            setUser
        }}>
            {children}
        </AuthContext.Provider>  
    );
}; 

export default function useAuth() {
    return useContext(AuthContext); 
}