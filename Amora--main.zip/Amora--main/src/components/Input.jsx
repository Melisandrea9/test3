import { LinearGradient } from "expo-linear-gradient";
import PropTypes from "prop-types";
import React, { forwardRef, memo, useState } from "react";
import { TextInput, StyleSheet } from "react-native";
import {
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import { gradients } from "../constants/colors";

const Input = forwardRef(({ style, gradient, ...rest }, ref) => {
    const [hasFocus, setHasFocus] = useState(false);

    return (
        <LinearGradient
            start={[0, 1]}
            end={[1, 0]}
            style={styles.gradientWrapper}
            colors={hasFocus ? gradient : gradients.default}>
            <TextInput
                {...rest}
                ref={ref}
                onBlur={() => setHasFocus(false)}
                onFocus={() => setHasFocus(true)}
                placeholderTextColor="#595575"
                style={[styles.input, style]}
            />
        </LinearGradient>
    );
});

Input.defaultProps = {
    gradient: gradients.primary,
};

Input.propTypes = {
    gradient: PropTypes.arrayOf(PropTypes.string).isRequired,
};

const styles = StyleSheet.create({
    gradientWrapper: {
        width: "100%",
        height: hp("6%"),
        borderRadius: 10,
        marginBottom: 10,
    },
    input: {
        flex: 1,
        backgroundColor: "#292C3A",
        paddingLeft: hp("2%"),
        fontSize: hp("1.7%"),
        color: "white",
        fontWeight: "500",
        borderRadius: 10,
        margin: 2.5,
    },
});

export default memo(Input);
