import React, {useRef, useEffect} from "react";
import { View, StyleSheet } from "react-native";
import {
    heightPercentageToDP as hp,
    widthPercentageToDP as wp,
} from "react-native-responsive-screen";

import Lottie from "lottie-react-native";

export default function Loader() {
    const animation = useRef(null);

    useEffect(() => {
        animation?.current.play();
    }, []);

    return (
        <View style={styles.container}>
            <Lottie
                ref={animation}
                style={{height: 120}}
                source={require("../../assets/animations/loading.json")} 
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        width: wp("100%"),
        height: hp("100%"),
        position: "absolute",
        backgroundColor: "#000",
        opacity: 0.5,
        alignItems: "center",
        justifyContent: "center",
    },
});
