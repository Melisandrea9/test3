import React from "react";
import { View } from "react-native";

export default function Breaker() {
    return <View style={{ marginTop: "10%" }} />;
}
