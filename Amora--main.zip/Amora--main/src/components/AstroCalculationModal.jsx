import React, {useRef} from "react";
import { View, Image, Text, StyleSheet } from "react-native";
import { useAuth } from "../hooks";
import { addSibling, destroySibling, showToast } from "../helpers";
import { useNavigation } from "@react-navigation/native";

import dayjs from "dayjs";
import Modal from "react-native-modal";
import Lottie from "lottie-react-native";
import Loader from "./Loader";
import axios from "axios";

export default function AstroCalculationModal({isVisible, tappedUser, setIsVisible}) {
    const animation = useRef(null);

    const {user} = useAuth();

    const navigation = useNavigation();

    const toggleModal = () => {
        setIsVisible(!isVisible);
    };

    const onCreatePress = async () => {
        toggleModal();
        addSibling(<Loader />);

        try {
            const {data} = await axios.post("https://json.astrologyapi.com/v1/synastry_horoscope", {
                p_day: dayjs(user.birthdate.toDate()).daysInMonth(),
                p_month: dayjs(user.birthdate.toDate()).month() + 1, 
                p_year: dayjs(user.birthdate.toDate()).year(),
                p_hour: dayjs(user.birthtime.toDate()).hour() + 1, 
                p_min: dayjs(user.birthtime.toDate()).minute() + 1, 
                p_lat: user.birthplace.latitude,
                p_lon: user.birthplace.latitude,
                p_tzone: 5.5,
                s_day: dayjs(tappedUser.birthdate.toDate()).daysInMonth(),
                s_month: dayjs(tappedUser.birthdate.toDate()).month() + 1, 
                s_year: dayjs(tappedUser.birthdate.toDate()).year(),
                s_hour: dayjs(tappedUser.birthtime.toDate()).hour() + 1, 
                s_min: dayjs(tappedUser.birthtime.toDate()).minute() + 1,
                s_lat: tappedUser.birthplace.latitude,
                s_lon: tappedUser.birthplace.latitude,
                s_tzone: 5.5,
            }, {
                auth: {
                    username: "620766",
                    password: "5bb9b1e19155596205780dd5897e3d92"
                }  
            });

            const formattedData = [
                {
                    title: `${user.displayName}'s planets`,
                    content: data.first
                },
                {
                    title: `${tappedUser.displayName}'s planets`,
                    content: data.second
                },
                {
                    title: "Synastry Aspects",
                    content: data.synastry.aspects
                }
            ];

            navigation.navigate("CalculationDetails", {data: formattedData});
        } catch (err) {
            showToast("Something went wrong"); 
            console.log(err); 
        } finally {
            destroySibling();
        }
    };

    return (
        <Modal 
            testID={"modal"}
            animationIn="zoomInDown"
            animationOut="zoomOutUp"
            animationInTiming={600}
            animationOutTiming={600}
            backdropTransitionInTiming={600}
            backdropTransitionOutTiming={600} 
            backdropColor="#000"
            backdropOpacity={0.9}
            isVisible={isVisible}>
            <View style={styles.container}>
                <Lottie
                    autoPlay
                    ref={animation}
                    style={styles.animation}
                    source={require("../../assets/animations/planet.json")} 
                />

                <View style={styles.imagesWrapper}>
                    <Image source={{uri: user?.photoURL}} style={styles.userImage} />
                    <View style={styles.tappedUserImageWrapper}>
                        <Image source={{uri: tappedUser?.photoURL}} style={styles.tappedUserImage} />
                    </View>
                </View>

                <View style={styles.titleAndDescriptionWrapper}>
                    <Text style={styles.title}>Create a synastry chart with {tappedUser?.displayName}?</Text>
                    <Text style={styles.description}>Anim ut labore laborum cillum eu et eiusmod nulla do officia. Magna nostrud esse aliqua voluptate ullamco excepteur m cillum eu et eiusmod nulla.</Text>
                </View>

                <Text onPress={onCreatePress} style={styles.createChartBtn}>Create chart</Text>
                <Text style={styles.notNowBtn} onPress={toggleModal}>Not now</Text>
            </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    container: { 
        backgroundColor: "white", 
        position: "relative", 
        alignSelf: "center", 
        width: 385, 
        height: 255, 
        borderRadius: 10 
    },
    tappedUserImage: {
        flex: 1, 
        borderRadius: 25
    },
    titleAndDescriptionWrapper: {
        marginHorizontal: 30, 
        alignItems: "center"
    },
    tappedUserImageWrapper: {
        width: 56, 
        height: 56, 
        borderRadius: 56/2, 
        backgroundColor: "white", 
        padding: 3, 
        right: 7
    },
    title: {
        fontSize: 17, 
        fontWeight: "bold", 
        alignSelf: "center", 
        marginVertical: 15
    },
    createChartBtn: {
        alignSelf: "center", 
        fontWeight: "bold", 
        fontSize: 16, 
        color: "#F914FF", 
        marginBottom: 7
    },
    notNowBtn: {
        alignSelf: "center", 
        color: "#8516FF", 
        fontSize: 13, 
        fontWeight: "bold"
    },
    description: {
        fontWeight: "bold", 
        color: "gray", 
        fontSize: 12, 
        marginBottom: 20
    },
    userImage: {
        width: 50, 
        height: 50, 
        borderRadius: 25
    },
    imagesWrapper: {
        flexDirection: "row", 
        marginTop: 30, 
        alignItems: "center", 
        alignSelf: "center"
    },
    animation: {
        position: "absolute", 
        left: -10, 
        top: -15,
        height: 100
    }
});