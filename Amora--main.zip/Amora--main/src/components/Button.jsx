import * as Haptics from "expo-haptics";
import PropTypes from "prop-types";
import { LinearGradient } from "expo-linear-gradient";
import React, { forwardRef, memo, useCallback } from "react";
import { Text, StyleSheet, TouchableOpacity } from "react-native";
import {
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import { gradients } from "../constants/colors";

const Button = forwardRef(({ gradient, style, haptic, onPress, title, ...rest }, ref) => {
    const handlePress = useCallback(
        (event) => {
            onPress?.(event);

            if (haptic) {
                Haptics.selectionAsync();
            }
        },
        [onPress]
    );

    return (
        <TouchableOpacity onPress={handlePress} style={[styles.container, style]} ref={ref} {...rest}>
            <LinearGradient start={[0, 1]} end={[1, 0]} style={styles.gradientWrapper} colors={gradient}>
                <Text style={styles.title}>{title}</Text>
            </LinearGradient>
        </TouchableOpacity>
    );
});

Button.defaultProps = {
    gradient: gradients.primary,
    haptic: true,
};

Button.propTypes = {
    gradient: PropTypes.arrayOf(PropTypes.string).isRequired,
    title: PropTypes.string.isRequired,
    containerStyle: PropTypes.object,
    haptic: PropTypes.bool,
};

const styles = StyleSheet.create({
    container: {
        width: "100%",
        height: hp("6%"),
    },
    gradientWrapper: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 10,
    },
    title: {
        fontWeight: "bold",
        textTransform: "uppercase",
        fontSize: hp("1.7%"),
        color: "white",
    },
});

export default memo(Button);
