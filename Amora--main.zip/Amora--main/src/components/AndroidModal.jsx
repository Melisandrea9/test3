import React, {forwardRef, useEffect} from "react";
import { View, Text, Pressable, StyleSheet, Image } from "react-native";
import { gradients } from "../constants/colors";
import { Entypo } from "@expo/vector-icons";

import RBSheet from "react-native-raw-bottom-sheet";

export default forwardRef(function AndroidModalNew({title, options}, ref) {
    useEffect(() => {
        if (ref?.current) {
            ref.current.open();
        }
    }, [ref?.current]);

    return (
        <RBSheet
            ref={ref}
            openDuration={250}
            height={options.length * 75}
            customStyles={{
                container: {
                    padding: 20
                }
            }}
        >
            <View>
                <View style={styles.headerWrapper}>
                    <Text style={styles.title}>{title}</Text>
                    <Entypo 
                        onPress={() => ref?.current.close()} 
                        name="cross" 
                        size={22} 
                        color="black" 
                    />
                </View>

                {options.map((option, index) => option !== null && (
                    <Pressable 
                        onPress={() => {
                            ref?.current.close();
                            option.callback();  
                        }} 
                        key={index.toString()} 
                        style={styles.optionWrapper}>
                        {option.icon && (
                            <Image source={option.icon} style={styles.icon} />
                        )}
                        <Text>{option.title}</Text> 
                    </Pressable>   
                ))} 
            </View>
        </RBSheet>
    );
});

const styles = StyleSheet.create({
    headerWrapper: {
        flexDirection: "row", 
        justifyContent: "space-between", 
        alignItems: "center", 
        marginBottom: 25
    },
    optionWrapper: {
        flexDirection: "row", 
        marginBottom: 10, 
        alignItems: "center"
    },
    title: {
        fontWeight: "600",
        fontSize: 15,
        color: gradients.primary[1]
    },
    icon: {
        width: 25, 
        marginRight: 15, 
        height: 25
    }
});