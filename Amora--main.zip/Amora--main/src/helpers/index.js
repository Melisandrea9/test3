/* eslint-disable react/react-in-jsx-scope */
import {Platform} from "react-native";
import { Loader } from "../components";

import RootSiblings from "react-native-root-siblings";
import Toast from "react-native-root-toast";

import * as regex from "../constants/regex";
import * as ImagePicker from "expo-image-picker";
import firebase from "firebase";

let id = 0;
const elements = [];

export const addSibling = (component) => {
    const sibling = new RootSiblings(component);
    id++;
    elements.push(sibling);
};

export const getAspectImage = (aspectName) => {
    switch (aspectName) {
    case "Trine": 
        return require("../../assets/trine.png");
    case "Sextile":    
        return require("../../assets/sextile.png");
    case "Opposition": 
        return require("../../assets/opposition.png");
    case "Square":    
        return require("../../assets/square.png");
    case "Conjunction": 
        return require("../../assets/conjunction.png");
    default: 
        return require("../../assets/square.png");
    } 
};

export const getPlannetImage = (plannetName) => {
    switch (plannetName) {
    case "Sun": 
        return require("../../assets/sun.png");
    case "Moon":    
        return require("../../assets/moon.png");
    case "Mars": 
        return require("../../assets/mars.png");
    case "Mercury":    
        return require("../../assets/mercury.png");
    case "Jupiter": 
        return require("../../assets/jupiter.png");
    case "Saturn":    
        return require("../../assets/saturn.png");
    case "Venus": 
        return require("../../assets/venus.png");
    case "Pluto":    
        return require("../../assets/pluto.png");
    case "Chiron": 
        return require("../../assets/chiron.png");
    case "Uranus":    
        return require("../../assets/uranus.png");
    case "Neptune": 
        return require("../../assets/neptune.png");
    case "Node":    
        return require("../../assets/north-node.png");
    case "Part of Fortune":    
        return require("../../assets/fortune.png");
    default: 
        return  require("../../assets/sun.png");
    } 
};

export const validateRegistrationFields = ({username, agreed, email, password}) => {
    if (!regex.username.test(username)) {
        return "Name should be minimum 3 chars, maximum 15 chars";
    } else if (!regex.email.test(email)) {
        return "Email format is invalid";
    } else if (!regex.password.test(password)) {
        return "Password should contain at least one digit, one lower and upper case letters, and be minimum 6 characters";
    } else if (!agreed) {
        return "You have to accept our privacy policy to continue.";
    }
};

export const generateRandomId = () => {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
        var r = (Math.random() * 16) | 0,
            v = c == "x" ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
};

export const takePhotoAsync = async () => {
    addSibling(<Loader />);

    try {
        const {status} = await ImagePicker.requestCameraPermissionsAsync();

        if (status === "granted") {
            const result = await ImagePicker.launchCameraAsync({
                allowsEditing: true,
                aspect: [1, 1],
            });

            if (result.cancelled) {
                destroySibling();
                return;
            }

            return result.uri;
        }
    } catch (err) {
        console.log(err);
        showToast("Something went wrong.");
    } finally {
        destroySibling();
    }
};

export const chooseImageAsync = async () => {
    addSibling(<Loader />);

    try {
        const {status} = await ImagePicker.requestMediaLibraryPermissionsAsync();

        if (status === "granted") {
            const result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                aspect: [4, 3],
                quality: 1,
                allowsEditing: true,
            });

            if (result.cancelled) {
                destroySibling();
                return;
            }

            return result.uri;
        }
    } catch (err) {
        console.log(err);
        showToast("Something went wrong.");
    } finally {
        destroySibling();
    }
};

export const destroySibling = () => {
    const lastSibling = elements.pop();
    lastSibling && lastSibling.destroy();
};

export const showToast = (msg) => {
    Toast.show(msg, {
        duration: Toast.durations.LONG,
        position: Toast.positions.BOTTOM,
        backgroundColor: "white",
        textColor: "black",
        shadow: true,
        animation: true,
        hideOnPress: true,
        delay: 0,
        onShow: () => {
            // calls on toast\`s appear animation start
        },
        onShown: () => {
            // calls on toast\`s appear animation end.
        },
        onHide: () => {
            // calls on toast\`s hide animation start.
        },
        onHidden: () => {
            // calls on toast\`s hide animation end.
        },
    });
};

export const multiUploadToStorage = async (
    localImages,
    pathName,
) => {
    let remoteUrls = [];
    for (let i=0; i<localImages.length; i++) {
        try {
            const localImage = localImages[i];
            const uuid = generateRandomId();
    
            const response = await fetch(localImage);
            const blob = await response.blob();
    
            //create the ref in firebase
            const ref = firebase.storage().ref().child(`${pathName}/${uuid}`);
    
            const snapshot = await ref.put(blob, {contentType: "image/jpg"});
            const remoteURL = await snapshot.ref.getDownloadURL();
    
            remoteUrls.push(remoteURL); 
        } catch (err) {
            alert(err);
            return;
        }
    }

    return remoteUrls;
};

export const uploadToStorage = async (
    localUri,
    pathName,
) => {
    try {
        const response = await fetch(localUri);
        const blob = await response.blob();

        const uuid = generateRandomId();

        //create the ref in firebase
        const ref = firebase.storage().ref().child(`${pathName}/${uuid}`);

        const snapshot = await ref.put(blob, {contentType: "image/jpg"});

        // Create a download URL
        const remoteURL = await snapshot.ref.getDownloadURL();

        return remoteURL;
    } catch (err) {
        alert(err);
        return;
    }
};

export const gererateId = (id1, id2) => (id1 > id2 ? id1 + id2 : id2 + id1);

export const getMatchedUserInfo = (users, userLoggedIn) => {
    const newUsers = { ...users };
    delete newUsers[userLoggedIn];

    const [id, user] = Object.entries(newUsers).flat();
    return { id, ...user };
};
