import "./src/lib/firebase";
import React from "react";
import { RootSiblingParent } from "react-native-root-siblings";
import { AuthProvider } from "./src/hooks/useAuth";

import {decode, encode} from "base-64";

import MainNavigator from "./src/navigation";

import * as SplashScreen from "expo-splash-screen";

if (!global.btoa) {
    global.btoa = encode;
}

if (!global.atob) {
    global.atob = decode;
}

SplashScreen.preventAutoHideAsync();

export default function App() {
    return (
        <RootSiblingParent>
            <AuthProvider>
                <MainNavigator />
            </AuthProvider>
        </RootSiblingParent>
    );
}
